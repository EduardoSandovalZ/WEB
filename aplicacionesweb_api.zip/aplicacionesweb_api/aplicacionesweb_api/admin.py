from django.contrib import admin
from aplicacionesweb_api.models import *

admin.site.register(Profiles)
